#ifndef _REST_UTIL_H
#define _REST_UTIL_H
#include "Sniffer_Rest_Util.h"
#include <Sniffer_Rest_Property.h>
#include <Sniffer_Data_Util.h>

bool saveData(Environment envirData,RestProperty restProperty);
#endif
